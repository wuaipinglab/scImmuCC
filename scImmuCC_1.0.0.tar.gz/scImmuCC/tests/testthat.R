library(testthat)
library(scImmuCC)

test_check("scImmuCC")
